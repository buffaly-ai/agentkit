﻿namespace ProtoScript.Interpretter.RuntimeInfo
{
}
